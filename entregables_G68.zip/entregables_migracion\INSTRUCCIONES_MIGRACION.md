# 📜 Guía de Migración y Reconstrucción Histórica G68

Este documento detalla el procedimiento para migrar el proyecto a un nuevo repositorio (o reconstruirlo en el repositorio de Diego), preservando la trazabilidad de cada integrante mediante la aplicación secuencial de parches.

## 📦 Inventario de Parches (Orden de Ejecución)

Los siguientes archivos `.patch` se han generado en la raíz del proyecto. Cada uno representa una etapa lógica de desarrollo.

1.  **`BE-Edwing-1-Infra.patch`**: *La Fundación*. Infraestructura Backend Java (Legacy Sneyky).
2.  **`DS-Diego-1-Tests.patch`**: *Calidad*. Scripts de prueba y validación (QA).
3.  **`DS-Alexis-1-Engine.patch`**: *El Cerebro*. Motor de sentimientos unificado (Supreme Integral) y léxicos.
4.  **`DS-Alexis-2-API.patch`**: *La Voz*. Servidor FastAPI y conexión.
5.  **`DS-Fernando-1-Docs.patch`**: *El Conocimiento*. Documentación y Notebooks de investigación.
6.  **`BE-Lorena-1-Logic.patch`**: *El Puente*. Lógica Java para conectar Backend con IA.
7.  **`FE-Florentino-1-UI.patch`**: *La Cara*. Estructura HTML y Estilos CSS.
8.  **`FE-Florentino-2-Interactions.patch`**: *La Vida*. Lógica JS, Dashboard y Micrófono.

> [!NOTE]
> **¿Por qué un solo zip? - Estrategia de "Lead Integrator"**
> Para una **reconstrucción histórica limpia**, se recomienda que una sola persona (el "Arquitecto" o "Lead") aplique estos parches secuencialmente. 
> *   Esto asegura que no haya conflictos de merge.
> *   La autoría de cada miembro se preserva usando el comando `--author` en cada commit.
> *   Si prefieren que cada uno aplique su parche real, deben enviarse el archivo correspondiente y esperar a que el anterior haya hecho merge para evitar conflictos de dependencias.

---

## 🛠️ Procedimiento de Reconstrucción

### Escenario A: Repositorio Nuevo (¡RECOMENDADO!)
Si Diego puede borrar el repo y crear uno nuevo (vacío), es la opción más limpia.

1.  **Crear Repo Vacío**: Diego crea el repo en GitHub/GitLab sin "Initialize with README".
2.  **Clonar en local**:
    ```bash
    git clone https://github.com/Diego/sentiment-api-G68.git
    cd sentiment-api-G68
    ```
3.  **Copiar Parches**: Pega todos los archivos `.patch` de la carpeta `entregables_migracion` aquí adentro.
4.  **Aplicar Parches Secuencialmente** (Ver abajo).

### Escenario B: Repositorio Existente (Si no se puede borrar)
Si ya tiene historia y no quieren borrarla:
1.  **Crear Rama Huérfana**:
    ```bash
    git checkout --orphan reconstruction/history-v1
    git rm -rf .  # Limpia todo
    ```
2.  **Aplicar Parches** en esta rama y luego hacer Force Push o Pull Request.

---

### 🔥 Ejecución de Parches (Paso a Paso)

Ejecuta estos bloques uno por uno en la terminal:

#### 1. Infraestructura (Edwing)
```bash
git apply --reject --whitespace=fix BE-Edwing-1-Infra.patch
git add .
git commit -m "feat(infra): Base architecture setup (Legacy Sneyky)" --author="Edwing Herrera <sneyky@g68.com>"
```

#### 2. Tests (Diego)
```bash
git apply --reject --whitespace=fix DS-Diego-1-Tests.patch
git add .
git commit -m "test(qa): Validation scripts and stress tests" --author="Diego Zapata <diego@g68.com>"
```

#### 3. Motor IA (Alexis)
```bash
git apply --reject --whitespace=fix DS-Alexis-1-Engine.patch
git add .
git commit -m "feat(ml): Unified Sentiment Engine (Supreme Integral)" --author="Alxs68 <alexis@g68.com>"
```

#### 4. API Python (Alexis)
```bash
git apply --reject --whitespace=fix DS-Alexis-2-API.patch
git add .
git commit -m "feat(api): FastAPI server exposure" --author="Alxs68 <alexis@g68.com>"
```

#### 5. Documentación (Fernando)
```bash
git apply --reject --whitespace=fix DS-Fernando-1-Docs.patch
git add .
git commit -m "docs: Research notebooks and project traceability" --author="Fernando <fernando@g68.com>"
```

#### 6. Lógica Java (Lorena)
```bash
git apply --reject --whitespace=fix BE-Lorena-1-Logic.patch
git add .
git commit -m "feat(backend): Java controller logic" --author="Lorena <lorena@g68.com>"
```

#### 7. Interfaz Gráfica (Florentino)
```bash
git apply --reject --whitespace=fix FE-Florentino-1-UI.patch
git add .
git commit -m "feat(ui): HTML structure and CSS styles" --author="Florentino <florentino@g68.com>"
```

#### 8. Interacciones (Florentino)
```bash
git apply --reject --whitespace=fix FE-Florentino-2-Interactions.patch
git add .
git commit -m "feat(js): Dashboard logic and Mic integration" --author="Florentino <florentino@g68.com>"
```

---

### Paso 3: Consolidación Final
Una vez reconstruida la historia en la rama `reconstruction/history-v1`:

1.  Sube la rama al repositorio remoto:
    ```bash
    git push origin reconstruction/history-v1
    ```
2.  En GitHub/GitLab, abre un **Pull Request** de `reconstruction/history-v1` hacia `main`.
3.  Al aceptar el PR, la historia del proyecto mostrará la evolución paso a paso, respetando la autoría de cada integrante.

> **Tip Importante**: Si `git apply` falla con conflictos (archivos `.rej`), significa que la carpeta no estaba totalmente limpia. Asegúrate de usar `git rm -rf .` al inicio (Opción B del Paso 1).
